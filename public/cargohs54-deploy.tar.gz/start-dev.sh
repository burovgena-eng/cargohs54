#!/bin/bash
cd /home/z/my-project
# Kill any existing server
pkill -f "next dev" 2>/dev/null
sleep 1
# Start server detached
setsid node node_modules/.bin/next dev -p 3000 > dev.log 2>&1 &
echo "Dev server started"
