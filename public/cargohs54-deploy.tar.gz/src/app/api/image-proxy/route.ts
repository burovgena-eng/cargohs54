import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth-helpers";

// Track rate per IP for unauthenticated requests
const ipRequestCounts = new Map<string, { count: number; resetAt: number }>();
const PROXY_MAX_ANON = 30; // per minute per IP for anonymous users
const PROXY_WINDOW_MS = 60_000;

const MAX_SIZE = 10 * 1024 * 1024; // 10MB

// Private/reserved IP ranges that must be blocked (SSRF protection)
function isPrivateIP(ip: string): boolean {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4) return true; // Not IPv4 — reject

  // 10.0.0.0/8
  if (parts[0] === 10) return true;
  // 172.16.0.0/12
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  // 192.168.0.0/16
  if (parts[0] === 192 && parts[1] === 168) return true;
  // 127.0.0.0/8
  if (parts[0] === 127) return true;
  // 169.254.0.0/16 (link-local / cloud metadata)
  if (parts[0] === 169 && parts[1] === 254) return true;
  // 0.0.0.0/8
  if (parts[0] === 0) return true;

  return false;
}

// Check if hostname resolves to a private IP (basic DNS check without actual lookup)
function isPrivateHostname(hostname: string): boolean {
  // Block common internal hostnames
  const blocked = ["localhost", "localhost.localdomain", "ip6-localhost", "ip6-loopback"];
  if (blocked.includes(hostname.toLowerCase())) return true;

  // Block IP-based hostnames directly
  const ipMatch = hostname.match(/^(\d+\.\d+\.\d+\.\d+)$/);
  if (ipMatch && isPrivateIP(ipMatch[1])) return true;

  return false;
}

export async function GET(req: NextRequest) {
  // Rate limiting for anonymous requests
  const user = await getCurrentUser(req).catch(() => null);
  if (!user) {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
    const now = Date.now();
    const entry = ipRequestCounts.get(ip);
    if (!entry || now > entry.resetAt) {
      ipRequestCounts.set(ip, { count: 1, resetAt: now + PROXY_WINDOW_MS });
    } else {
      entry.count++;
      if (entry.count > PROXY_MAX_ANON) {
        return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 });
      }
    }
  }

  const url = req.nextUrl.searchParams.get("url");

  if (!url) {
    return NextResponse.json({ error: "URL parameter is required" }, { status: 400 });
  }

  // Validate URL format
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    return NextResponse.json({ error: "Invalid URL" }, { status: 400 });
  }

  // Only allow http/https
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    return NextResponse.json({ error: "Only HTTP(S) URLs are allowed" }, { status: 400 });
  }

  // SSRF protection: block private hostnames
  if (isPrivateHostname(parsedUrl.hostname)) {
    return NextResponse.json({ error: "URL not allowed" }, { status: 400 });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000); // 15s timeout

    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        Referer: url,
      },
      redirect: "follow",
    });

    clearTimeout(timeout);

    if (!res.ok) {
      return NextResponse.json({ error: `Upstream returned ${res.status}` }, { status: 502 });
    }

    const contentType = res.headers.get("content-type") || "";
    const contentLength = res.headers.get("content-length");

    // Check content type is an image
    const baseContentType = contentType.split(";")[0].trim().toLowerCase();
    if (!baseContentType.startsWith("image/")) {
      return NextResponse.json(
        { error: "URL does not point to an image" },
        { status: 400 }
      );
    }

    // Check size limit from header
    if (contentLength && parseInt(contentLength) > MAX_SIZE) {
      return NextResponse.json({ error: "Image too large (max 10MB)" }, { status: 413 });
    }

    // Stream the response body directly (no buffering into memory)
    if (!res.body) {
      return NextResponse.json({ error: "Empty response" }, { status: 502 });
    }

    return new NextResponse(res.body, {
      status: 200,
      headers: {
        "Content-Type": baseContentType,
        "Cache-Control": "public, max-age=86400",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    if (err instanceof Error && err.name === "AbortError") {
      return NextResponse.json({ error: "Image fetch timed out" }, { status: 504 });
    }
    console.error("Image proxy error:", err);
    return NextResponse.json({ error: "Failed to fetch image" }, { status: 502 });
  }
}
