import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth-helpers";
import { db } from "@/lib/db";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser(req);
    if (!user) {
      return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
    }

    const { id } = await params;

    const order = await db.order.findUnique({
      where: { id },
      include: {
        user: {
          select: { id: true, name: true, email: true, phone: true },
        },
        messages: {
          include: {
            user: {
              select: { id: true, name: true, role: true },
            },
          },
          orderBy: { createdAt: "asc" },
        },
        items: true,
      },
    });

    if (!order) {
      return NextResponse.json(
        { error: "Заявка не найдена" },
        { status: 404 }
      );
    }

    // Clients can only see their own orders
    if (user.role === "CLIENT" && order.userId !== user.id) {
      return NextResponse.json({ error: "Доступ запрещён" }, { status: 403 });
    }

    return NextResponse.json(order);
  } catch (error) {
    console.error("GET order error:", error);
    return NextResponse.json(
      { error: "Ошибка при получении заявки" },
      { status: 500 }
    );
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser(req);
    if (!user) {
      return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
    }

    const { id } = await params;
    const body = await req.json();

    const order = await db.order.findUnique({ where: { id } });

    if (!order) {
      return NextResponse.json(
        { error: "Заявка не найдена" },
        { status: 404 }
      );
    }

    // Validate status value
    const VALID_STATUSES = ["NEW", "APPROVED", "SHIPPED", "DELIVERED", "CANCELLED"];
    if (body.status && !VALID_STATUSES.includes(body.status)) {
      return NextResponse.json({ error: "Некорректный статус" }, { status: 400 });
    }

    // Validate adminNote length
    if (body.adminNote !== undefined && typeof body.adminNote === "string" && body.adminNote.length > 10000) {
      return NextResponse.json({ error: "Заметка слишком длинная (максимум 10 000 символов)" }, { status: 400 });
    }

    // Only admins can update order details (status, prices, notes)
    if (user.role !== "ADMIN") {
      // Clients can only cancel their own orders if status is NEW (atomic check)
      if (body.status === "CANCELLED" && order.userId === user.id && order.status === "NEW") {
        const result = await db.order.updateMany({
          where: { id, userId: user.id, status: "NEW" },
          data: { status: "CANCELLED" },
        });
        if (result.count === 0) {
          return NextResponse.json({ error: "Невозможно отменить заявку" }, { status: 400 });
        }
        const updated = await db.order.findUnique({ where: { id } });
        return NextResponse.json(updated);
      }
      return NextResponse.json({ error: "Доступ запрещён" }, { status: 403 });
    }

    // If items array is provided, update individual item prices in a transaction
    if (body.items && Array.isArray(body.items)) {
      await db.$transaction(async (tx) => {
        for (const item of body.items) {
          if (!item.id) continue;

          const updateData: Record<string, unknown> = {};
          if (item.itemPriceCNY !== undefined) updateData.itemPriceCNY = item.itemPriceCNY;
          if (item.deliveryPriceRUB !== undefined) updateData.deliveryPriceRUB = item.deliveryPriceRUB;
          if (item.totalPriceRUB !== undefined) updateData.totalPriceRUB = item.totalPriceRUB;

          if (Object.keys(updateData).length > 0) {
            await tx.orderItem.updateMany({
              where: { id: item.id, orderId: id },
              data: updateData,
            });
          }
        }

        // Recalculate Order totals as sum of all item totals
        const allItems = await tx.orderItem.findMany({
          where: { orderId: id },
          select: { totalPriceRUB: true, deliveryPriceRUB: true },
        });

        const orderTotalPrice = allItems.reduce(
          (sum, i) => sum + (i.totalPriceRUB || 0),
          0
        );
        const orderDeliveryPrice = allItems.reduce(
          (sum, i) => sum + (i.deliveryPriceRUB || 0),
          0
        );

        await tx.order.update({
          where: { id },
          data: {
            totalPriceRUB: orderTotalPrice || null,
            deliveryPriceRUB: orderDeliveryPrice || null,
            ...(body.status && { status: body.status }),
            ...(body.adminNote !== undefined && { adminNote: body.adminNote }),
            ...(body.itemPriceCNY !== undefined && { itemPriceCNY: body.itemPriceCNY }),
          },
        });
      });

      // Return the updated order with items
      const updated = await db.order.findUnique({
        where: { id },
        include: {
          user: {
            select: { id: true, name: true, email: true },
          },
          items: true,
        },
      });

      return NextResponse.json(updated);
    }

    // Standard update without items
    const updated = await db.order.update({
      where: { id },
      data: {
        ...(body.status && { status: body.status }),
        ...(body.itemPriceCNY !== undefined && { itemPriceCNY: body.itemPriceCNY }),
        ...(body.deliveryPriceRUB !== undefined && { deliveryPriceRUB: body.deliveryPriceRUB }),
        ...(body.totalPriceRUB !== undefined && { totalPriceRUB: body.totalPriceRUB }),
        ...(body.adminNote !== undefined && { adminNote: body.adminNote }),
      },
      include: {
        user: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PATCH order error:", error);
    return NextResponse.json(
      { error: "Ошибка при обновлении заявки" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser(req);
    if (!user) {
      return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
    }

    const { id } = await params;

    const order = await db.order.findUnique({ where: { id } });

    if (!order) {
      return NextResponse.json(
        { error: "Заявка не найдена" },
        { status: 404 }
      );
    }

    // Only CANCELLED orders can be deleted
    if (order.status !== "CANCELLED") {
      return NextResponse.json(
        { error: "Удалить можно только отменённые заявки" },
        { status: 400 }
      );
    }

    // Clients can delete only their own orders, admins can delete any
    if (user.role === "CLIENT" && order.userId !== user.id) {
      return NextResponse.json({ error: "Доступ запрещён" }, { status: 403 });
    }

    // Cascade deletes messages and items automatically via schema
    await db.order.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE order error:", error);
    return NextResponse.json(
      { error: "Ошибка при удалении заявки" },
      { status: 500 }
    );
  }
}
