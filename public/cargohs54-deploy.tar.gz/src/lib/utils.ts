import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Proxy an external image URL through our server to bypass hotlink protection.
 * Local paths (/uploads/...) are returned as-is.
 */
/**
 * Check if a string is a data URL (e.g. data:image/png;base64,...)
 */
function isDataUrl(url: string): boolean {
  return url.startsWith("data:");
}

/**
 * Validate that a URL is safe for rendering (not javascript:, vbscript:, etc.)
 */
export function isSafeUrl(url: string): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return ["http:", "https:", "mailto:", "tel:"].includes(parsed.protocol);
  } catch {
    // Relative paths, data: URLs, etc. are safe
    return url.startsWith("/") || isDataUrl(url);
  }
}

/**
 * Proxy an external image URL through our server to bypass hotlink protection.
 * Data URLs and local paths are returned as-is.
 */
export function proxyImageUrl(url: string): string {
  if (!url) return url;
  // Data URLs — return directly (no proxy needed)
  if (isDataUrl(url)) return url;
  // Already proxied or local
  if (url.startsWith("/uploads/") || url.startsWith("/api/")) return url;
  // External URL — proxy through our endpoint
  try {
    return `/api/image-proxy?url=${encodeURIComponent(url)}`;
  } catch {
    return url;
  }
}
