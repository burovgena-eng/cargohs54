// Shared status map with dark mode variants for badges
export const STATUS_MAP: Record<string, { label: string; className: string }> = {
  NEW: {
    label: "Новая",
    className: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-800",
  },
  APPROVED: {
    label: "Принята",
    className: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-900/40 dark:text-sky-300 dark:border-sky-800",
  },
  SHIPPED: {
    label: "Отправлена",
    className: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/40 dark:text-orange-300 dark:border-orange-800",
  },
  DELIVERED: {
    label: "Доставлена",
    className: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-800",
  },
  CANCELLED: {
    label: "Отменена",
    className: "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/40 dark:text-red-300 dark:border-red-800",
  },
};

// Fallback for unknown statuses
export const STATUS_FALLBACK = "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200";
