export { default } from "next-auth";
export const authOptions = {}; // re-export from auth-options if needed
