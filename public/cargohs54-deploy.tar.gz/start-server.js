const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const logFile = fs.openSync(path.join(__dirname, 'dev.log'), 'a');
const errFile = fs.openSync(path.join(__dirname, 'dev.log'), 'a');

const child = spawn('node', [path.join(__dirname, 'node_modules/.bin/next'), 'dev', '-p', '3000'], {
  detached: true,
  stdio: ['ignore', logFile, errFile],
  cwd: __dirname,
});

child.unref();
console.log(`Dev server started with PID ${child.pid}`);
